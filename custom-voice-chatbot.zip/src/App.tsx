import React, { useState, useEffect, useRef, FormEvent } from 'react';
import { 
  Bot, 
  User, 
  Send, 
  Image as ImageIcon, 
  Upload, 
  Globe, 
  FileText, 
  Volume2, 
  VolumeX, 
  Plus, 
  Trash2, 
  Check, 
  HelpCircle, 
  Loader2, 
  Database,
  CheckSquare,
  Square,
  AlertCircle,
  Sparkles,
  Info,
  X,
  FileUp,
  RefreshCw
} from 'lucide-react';

interface KBDocument {
  id: string;
  title: string;
  content: string;
  source: string; // 'manual' | 'file' | 'url'
  url?: string;
  isActive: boolean;
  createdAt: string;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  image?: string; // base64 representation if sent
  timestamp: string;
  isVoiceTranscript?: boolean;
}

export default function App() {
  // Tab states: 'chat' | 'voice'
  const [activeTab, setActiveTab] = useState<'chat' | 'voice'>('chat');
  
  // Knowledge Base (KB) States
  const [kbDocs, setKbDocs] = useState<KBDocument[]>([]);
  const [isLoadingKB, setIsLoadingKB] = useState(false);
  const [kbError, setKbError] = useState<string | null>(null);
  
  // Active KB IDs
  const [activeKbIds, setActiveKbIds] = useState<string[]>([]);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  
  // Create KB States
  const [showAddKbModal, setShowAddKbModal] = useState(false);
  const [newKbType, setNewKbType] = useState<'manual' | 'file' | 'url'>('manual');
  const [manualTitle, setManualTitle] = useState('');
  const [manualContent, setManualContent] = useState('');
  const [crawlUrl, setCrawlUrl] = useState('');
  const [isAddingDoc, setIsAddingDoc] = useState(false);
  const [addDocError, setAddDocError] = useState<string | null>(null);
  
  // Text Chat States
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "Hello! I am Shivbot, your personal helper. You can upload custom files (including PDFs, Word documents .doc/.docx, text logs, or JSON configs), draft notes, or crawl web pages into my Knowledge Base on the left. Toggle active cards to guide my context! You can also click the paperclip attachment underneath to upload real-time images (.jpeg, .png, .jpg) directly with your queries.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatImageBase64, setChatImageBase64] = useState<string | null>(null);
  const [isGeneratingChat, setIsGeneratingChat] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Real-time Voice States
  const [isVoiceSessionActive, setIsVoiceSessionActive] = useState(false);
  const [voiceConnectionState, setVoiceConnectionState] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [voiceTranscripts, setVoiceTranscripts] = useState<{ id: string; sender: 'user' | 'model'; text: string }[]>([]);
  
  // Audio Streaming Core References
  const wsRef = useRef<WebSocket | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const micProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const micSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const audioQueueRef = useRef<AudioBufferSourceNode[]>([]);
  const nextStartTimeRef = useRef<number>(0);
  const voiceTranscriptsEndRef = useRef<HTMLDivElement>(null);

  // Voice Retry Management
  const voiceRetryCountRef = useRef<number>(0);
  const voiceRetryTimeoutRef = useRef<any>(null);
  const isVoiceActiveRequestRef = useRef<boolean>(false);
  const chatAbortControllerRef = useRef<AbortController | null>(null);

  // Load Knowledge Base on startup, clearing previous uploads on fresh refresh/start
  useEffect(() => {
    const initApp = async () => {
      try {
        await fetch('/api/kb/clear', { method: 'POST' });
      } catch (err) {
        console.error('Failed to sweep knowledge base clean on start:', err);
      }
      fetchKB();
    };
    initApp();
  }, []);

  const renewChatAndClearKB = async () => {
    // 1. Abort any active streaming HTTP fetches
    if (chatAbortControllerRef.current) {
      chatAbortControllerRef.current.abort();
      chatAbortControllerRef.current = null;
    }

    // 2. Disconnect any active real-time voice sessions
    disconnectVoiceSession(true);

    try {
      await fetch('/api/kb/clear', { method: 'POST' });
      setKbDocs([]);
      setActiveKbIds([]);
      setChatInput('');
      setChatImageBase64(null);
      setChatError(null);
      setAddDocError(null);
      setKbError(null);
      setChatMessages([
        {
          role: 'assistant',
          content: "Hello! I am Shivbot, your personal helper. You can upload custom files (including PDFs, Word documents .doc/.docx, text logs, or JSON configs), draft notes, or crawl web pages into my Knowledge Base on the left. Toggle active cards to guide my context! You can also click the paperclip attachment underneath to upload real-time images (.jpeg, .png, .jpg) directly with your queries.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err: any) {
      console.error('Failed to renew session:', err);
      setChatError('Failed to reset session and purge documents: ' + (err.message || 'Server error'));
    }
  };

  // Sync scroll on chat transcript lists
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isGeneratingChat]);

  useEffect(() => {
    voiceTranscriptsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [voiceTranscripts]);

  // Clean elements on unmount
  useEffect(() => {
    return () => {
      disconnectVoiceSession();
    };
  }, []);

  const fetchKB = async () => {
    setIsLoadingKB(true);
    setKbError(null);
    try {
      const res = await fetch('/api/kb');
      if (!res.ok) throw new Error('Could not pull knowledge records');
      const data = await res.json();
      setKbDocs(data);
      // Automatically activate all loaded documents
      const activeIds = data.filter((doc: KBDocument) => doc.isActive).map((doc: KBDocument) => doc.id);
      setActiveKbIds(activeIds);
    } catch (err: any) {
      setKbError(err.message || 'Failed to pull knowledge documents from filesystem.');
    } finally {
      setIsLoadingKB(false);
    }
  };

  const toggleKbActive = async (id: string) => {
    const doc = kbDocs.find(d => d.id === id);
    if (!doc) return;
    const originalIsActive = doc.isActive;
    
    // Optimistic Update
    setKbDocs(prev => prev.map(d => d.id === id ? { ...d, isActive: !originalIsActive } : d));
    setActiveKbIds(prev => 
      !originalIsActive 
        ? [...prev, id] 
        : prev.filter(x => x !== id)
    );

    try {
      const res = await fetch(`/api/kb/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !originalIsActive })
      });
      if (!res.ok) throw new Error('Unsuccessful status save');
    } catch (e) {
      // Revert if error
      setKbDocs(prev => prev.map(d => d.id === id ? { ...d, isActive: originalIsActive } : d));
      setActiveKbIds(prev => 
        originalIsActive 
          ? [...prev, id] 
          : prev.filter(x => x !== id)
      );
    }
  };

  const deleteKbDoc = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (deleteConfirmId !== id) {
      setDeleteConfirmId(id);
      // Auto-reset confirmation state after 4 seconds if not clicked again
      setTimeout(() => {
        setDeleteConfirmId(current => current === id ? null : current);
      }, 4000);
      return;
    }

    try {
      const res = await fetch(`/api/kb/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Could not delete knowledge file');
      setKbDocs(prev => prev.filter(d => d.id !== id));
      setActiveKbIds(prev => prev.filter(x => x !== id));
      setDeleteConfirmId(null);
    } catch (err: any) {
      console.error('Deletion error:', err);
      setKbError(err.message || 'Error occurred while deleting document.');
    }
  };

  // Create Knowledge base methods
  const handleAddManualKB = async (e: FormEvent) => {
    e.preventDefault();
    if (!manualTitle.trim() || !manualContent.trim()) return;
    setIsAddingDoc(true);
    setAddDocError(null);
    try {
      const res = await fetch('/api/kb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: manualTitle,
          content: manualContent,
          source: 'manual'
        })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Unable to store document');
      }
      const newDoc = await res.json();
      setKbDocs(prev => [newDoc, ...prev]);
      setActiveKbIds(prev => [newDoc.id, ...prev]);
      
      // Reset inputs
      setManualTitle('');
      setManualContent('');
      setShowAddKbModal(false);
    } catch (err: any) {
      setAddDocError(err.message);
    } finally {
      setIsAddingDoc(false);
    }
  };

  const handleCrawlerKB = async (e: FormEvent) => {
    e.preventDefault();
    if (!crawlUrl.trim()) return;
    setIsAddingDoc(true);
    setAddDocError(null);
    try {
      const res = await fetch('/api/kb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: crawlUrl,
          source: 'url'
        })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Website crawl failed.');
      }
      const newDoc = await res.json();
      setKbDocs(prev => [newDoc, ...prev]);
      setActiveKbIds(prev => [newDoc.id, ...prev]);
      
      setCrawlUrl('');
      setShowAddKbModal(false);
    } catch (err: any) {
      setAddDocError(err.message);
    } finally {
      setIsAddingDoc(false);
    }
  };

  const handleFileUploadKB = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAddingDoc(true);
    setAddDocError(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/kb/upload', {
        method: 'POST',
        body: formData
      });
      
      const contentType = res.headers.get('content-type');
      if (!res.ok) {
        let errorMsg = 'Processing uploaded file failed';
        if (contentType && contentType.includes('application/json')) {
          const data = await res.json();
          errorMsg = data.error || errorMsg;
        } else {
          const text = await res.text();
          // Extract title/message from HTML error if possible, or truncate
          const titleMatch = text.match(/<pre>([\s\S]*?)<\/pre>/i) || text.match(/<title>([\s\S]*?)<\/title>/i);
          errorMsg = titleMatch ? titleMatch[1].trim() : text.substring(0, 120).trim() || errorMsg;
        }
        throw new Error(errorMsg);
      }

      if (contentType && contentType.includes('application/json')) {
        const newDoc = await res.json();
        setKbDocs(prev => [newDoc, ...prev]);
        setActiveKbIds(prev => [newDoc.id, ...prev]);
        setShowAddKbModal(false);
      } else {
        throw new Error('Server returned an unexpected non-JSON response.');
      }
    } catch (err: any) {
      setAddDocError(err.message);
    } finally {
      setIsAddingDoc(false);
    }
  };

  // Handle standard Chat panel submission
  const handleSelectImageForChat = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setChatImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const executeSendChat = async (e: FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() && !chatImageBase64) return;

    // Abort previous chat stream if running
    if (chatAbortControllerRef.current) {
      chatAbortControllerRef.current.abort();
    }
    const controller = new AbortController();
    chatAbortControllerRef.current = controller;

    const userMessage: ChatMessage = {
      role: 'user',
      content: chatInput,
      image: chatImageBase64 || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setChatImageBase64(null);
    setIsGeneratingChat(true);
    setChatError(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          messages: [...chatMessages, userMessage],
          activeKbIds
        })
      });

      if (!res.ok) {
        const text = await res.text();
        let errMsg = 'Server rejected response orchestration';
        try {
          const parsed = JSON.parse(text);
          errMsg = parsed.error || errMsg;
        } catch (err) {
          errMsg = text || errMsg;
        }
        throw new Error(errMsg);
      }

      // Add assistant placeholder to stream text into
      setChatMessages(prev => [...prev, {
        role: 'assistant',
        content: '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);

      const reader = res.body?.getReader();
      if (!reader) {
        throw new Error('Response body is not a readable stream.');
      }

      const decoder = new TextDecoder('utf-8');
      let done = false;
      let accumulatedText = '';

      while (!done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          const chunk = decoder.decode(value, { stream: !done });
          accumulatedText += chunk;
          
          setChatMessages(prev => {
            const copy = [...prev];
            if (copy.length > 0 && copy[copy.length - 1].role === 'assistant') {
              copy[copy.length - 1] = {
                ...copy[copy.length - 1],
                content: accumulatedText
              };
            }
            return copy;
          });
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // Silence aborted request errors safely
        return;
      }
      setChatError(err.message || 'An error occurred forwarding your message.');
    } finally {
      setIsGeneratingChat(false);
    }
  };


  // ==========================================
  // VOICE CONVERSATION PORTAL METHODS
  // ==========================================

  // Float32 mic array converter to 16bit signed binary PCM format
  const float32ToInt16 = (buffer: Float32Array): Int16Array => {
    let l = buffer.length;
    let buf = new Int16Array(l);
    while (l--) {
      let s = Math.max(-1, Math.min(1, buffer[l]));
      buf[l] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return buf;
  };

  // Serialize array as raw base64 string safely
  const bufferToBase64 = (buffer: Int16Array): string => {
    let binary = '';
    const bytes = new Uint8Array(buffer.buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };

  // Convert incoming Base64 16kHz audio response to playable Buffer segments
  const base64ToFloat32 = (base64: string): Float32Array => {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }
    return float32Array;
  };

  // Gapless voice queue scheduler
  const playAudioChunk = (float32Data: Float32Array) => {
    const audioCtx = audioCtxRef.current;
    if (!audioCtx) return;

    // Standard Gemini voice response sample rate is 24000Hz PCM
    const sampleRate = 24000;
    const audioBuffer = audioCtx.createBuffer(1, float32Data.length, sampleRate);
    audioBuffer.getChannelData(0).set(float32Data);

    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioCtx.destination);

    const now = audioCtx.currentTime;
    let startTime = nextStartTimeRef.current;

    // Sync buffer flow
    if (startTime < now) {
      startTime = now + 0.08; 
    }

    source.start(startTime);
    nextStartTimeRef.current = startTime + audioBuffer.duration;
    audioQueueRef.current.push(source);
  };

  // Clears active playback immediately on interruption/mute
  const stopAndClearAudioQueue = () => {
    audioQueueRef.current.forEach((source) => {
      try {
        source.stop();
      } catch (e) {}
    });
    audioQueueRef.current = [];
    nextStartTimeRef.current = 0;
  };

  // Spin real-time connection with Gemini Voice API via local server WebSocket proxy
  const handleVoiceSessionFailure = (errMsg: string) => {
    if (!isVoiceActiveRequestRef.current) {
      return;
    }

    disconnectVoiceSession(false);

    voiceRetryCountRef.current += 1;
    const retryDelay = Math.min(1000 * Math.pow(2, voiceRetryCountRef.current - 1), 16000) + Math.floor(Math.random() * 800);
    
    setVoiceConnectionState('connecting');
    setVoiceError(`${errMsg} Reconnecting (attempt ${voiceRetryCountRef.current}) in ${(retryDelay / 1000).toFixed(1)}s...`);
    
    console.log(`[Voice Retry] Scheduled retry #${voiceRetryCountRef.current} in ${retryDelay}ms due to: ${errMsg}`);

    if (voiceRetryTimeoutRef.current) {
      clearTimeout(voiceRetryTimeoutRef.current);
    }

    voiceRetryTimeoutRef.current = setTimeout(() => {
      initializeVoiceSession();
    }, retryDelay);
  };

  const disconnectVoiceSession = (isManual = true) => {
    if (isManual) {
      isVoiceActiveRequestRef.current = false;
      voiceRetryCountRef.current = 0;
      if (voiceRetryTimeoutRef.current) {
        clearTimeout(voiceRetryTimeoutRef.current);
        voiceRetryTimeoutRef.current = null;
      }
      setIsVoiceSessionActive(false);
      setVoiceConnectionState('disconnected');
    } else {
      setIsVoiceSessionActive(false);
    }
    
    // 1. Tear down mic listener nodes
    if (micProcessorRef.current) {
      try { micProcessorRef.current.disconnect(); } catch (e) {}
      micProcessorRef.current.onaudioprocess = null;
      micProcessorRef.current = null;
    }
    if (micSourceRef.current) {
      try { micSourceRef.current.disconnect(); } catch (e) {}
      micSourceRef.current = null;
    }

    // 2. Clear micro stream capture tracks
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    // 3. Purge response queues 
    stopAndClearAudioQueue();

    if (audioCtxRef.current) {
      try { audioCtxRef.current.close(); } catch (e) {}
      audioCtxRef.current = null;
    }

    // 4. Teardown active Websockets
    if (wsRef.current) {
      try { wsRef.current.close(); } catch (e) {}
      wsRef.current = null;
    }
  };

  const initializeVoiceSession = async () => {
    isVoiceActiveRequestRef.current = true;
    
    if (voiceRetryTimeoutRef.current) {
      clearTimeout(voiceRetryTimeoutRef.current);
      voiceRetryTimeoutRef.current = null;
    }

    stopAndClearAudioQueue();
    
    if (voiceRetryCountRef.current === 0) {
      setVoiceTranscripts([]);
      setVoiceError(null);
    }
    setVoiceConnectionState('connecting');

    try {
      // 1. Establish Audio Context for microphone and speaker setup
      const AudioCtxConstructor = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxConstructor({ sampleRate: 16000 }); // User microphone is sampled to standard 16kHz
      audioCtxRef.current = audioCtx;

      // Ensure active microphone permission
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      // 2. Open Websocket to local server with custom active parameters
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const socketUrl = `${protocol}//${window.location.host}/live?activeKbIds=${activeKbIds.join(',')}`;
      console.log('Connecting voice WebSocket path:', socketUrl);

      const ws = new WebSocket(socketUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('Voice socket interface initialized successfully');
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        
        if (msg.type === 'ready') {
          voiceRetryCountRef.current = 0;
          setVoiceError(null);
          
          setVoiceConnectionState('connected');
          setIsVoiceSessionActive(true);
          
          // Connect Microphone to processors only after stream is negotiated
          const source = audioCtx.createMediaStreamSource(stream);
          micSourceRef.current = source;

          const processor = audioCtx.createScriptProcessor(4096, 1, 1);
          micProcessorRef.current = processor;

          source.connect(processor);
          processor.connect(audioCtx.destination);

          processor.onaudioprocess = (e) => {
            const inputChannel = e.inputBuffer.getChannelData(0);
            const int16Buffer = float32ToInt16(inputChannel);
            const base64Audio = bufferToBase64(int16Buffer);

            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
              wsRef.current.send(JSON.stringify({
                type: 'audio',
                data: base64Audio
              }));
            }
          };
          
          setVoiceTranscripts([{
            id: 'init',
            sender: 'model',
            text: "Hello! Voice channel open. Ask me anything from your chosen custom knowledge base!"
          }]);
        }

        if (msg.type === 'audio' && msg.data) {
          const float32Response = base64ToFloat32(msg.data);
          playAudioChunk(float32Response);
        }

        if (msg.type === 'interrupted') {
          console.log('Gemini voice stream interrupted. Purging audio queues.');
          stopAndClearAudioQueue();
        }

        if (msg.type === 'transcription') {
          const text = msg.text;
          const sender = msg.origin === 'model' ? 'model' : 'user';
          
          setVoiceTranscripts(prev => {
            // Let's combine concurrent messages from the same sender to look cleanly structured
            if (prev.length > 0 && prev[prev.length - 1].sender === sender) {
              const last = prev[prev.length - 1];
              return [...prev.slice(0, prev.length - 1), { ...last, text: last.text + ' ' + text }];
            } else {
              return [...prev, { id: 'voice_' + Date.now() + Math.random(), sender, text }];
            }
          });
        }

        if (msg.type === 'error') {
          console.warn('Voice WebSocket reported service error:', msg.text);
          if (isVoiceActiveRequestRef.current) {
            handleVoiceSessionFailure(msg.text || 'Bridge server exception.');
          } else {
            setVoiceError(msg.text || 'Bridge server exception.');
            disconnectVoiceSession(true);
          }
        }
      };

      ws.onclose = () => {
        console.log('Voice Socket closed. Active state:', isVoiceActiveRequestRef.current);
        if (isVoiceActiveRequestRef.current) {
          handleVoiceSessionFailure('Voice socket connection lost.');
        } else {
          setVoiceConnectionState('disconnected');
          setIsVoiceSessionActive(false);
        }
      };

      ws.onerror = (e) => {
        console.error('WS Connection error:', e);
        if (isVoiceActiveRequestRef.current) {
          handleVoiceSessionFailure('Connection negotiation failed to establish.');
        } else {
          setVoiceError('Could not negotiate connection with target bridge.');
          setVoiceConnectionState('error');
          disconnectVoiceSession(true);
        }
      };

    } catch (e: any) {
      console.error('Failed to configure audio environment:', e);
      setVoiceError(e.message || 'Microphone context initialization failed. Please check permissions.');
      setVoiceConnectionState('error');
      disconnectVoiceSession(true);
    }
  };

  const toggleVoiceSession = () => {
    if (isVoiceActiveRequestRef.current) {
      disconnectVoiceSession(true);
    } else {
      initializeVoiceSession();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased">
      
      {/* 🚀 HEADER CONSOLE */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-6 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
            <Bot size={24} className="animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Shivbot
              <span className="text-[10px] bg-slate-800 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-normal">
                GEMINI LIVE & VISION ACTIVE
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Manage custom knowledge papers, chat with images (.jpeg, .png, .jpg), or use low-latency real-time voice streaming
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex bg-slate-950/80 p-1 rounded-lg border border-slate-850">
            <button 
              onClick={() => setActiveTab('chat')}
              className={`px-4 py-1.5 rounded-md text-xs font-medium cursor-pointer transition ${
                activeTab === 'chat' 
                  ? 'bg-slate-800 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              💬 Text & Image Chat
            </button>
            <button 
              onClick={() => setActiveTab('voice')}
              className={`px-4 py-1.5 rounded-md text-xs font-medium cursor-pointer transition flex items-center gap-1.5 ${
                activeTab === 'voice' 
                  ? 'bg-emerald-600 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🎙️ Real-time Voice
              {isVoiceSessionActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping inline-block" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Core Columns */}
      <main className="flex-1 max-w-7xl w-full mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 p-6 overflow-hidden">
        
        {/* ==========================================
            LEFT COLUMN : KNOWLEDGE BASE CONSOLE
            ========================================== */}
        <section className="md:col-span-4 flex flex-col bg-slate-900/60 border border-slate-800/80 rounded-2xl overflow-hidden p-5 max-h-[82vh]">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 mb-4">
            <div className="flex items-center gap-2 text-slate-300 font-semibold text-sm">
              <Database size={18} className="text-emerald-400" />
              Custom Knowledge Base
              <span className="text-xs font-normal text-slate-500 bg-slate-950 px-2 py-0.5 rounded-full">
                {kbDocs.length}
              </span>
            </div>
            
            <button 
              onClick={() => setShowAddKbModal(true)}
              className="p-1 px-2.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs font-medium rounded-lg border border-emerald-500/20 transition cursor-pointer flex items-center gap-1"
            >
              <Plus size={14} /> Add Source
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-4 bg-slate-950/60 p-3 rounded-lg border border-slate-800/40">
            Check files below to inject them as context parameters. Selected knowledge files are automatically bundled with AI outputs!
          </p>

          {/* Active Docs Banner */}
          <div className="bg-slate-950/90 text-xs px-3 py-2 rounded-lg border border-slate-800/80 flex items-center justify-between mb-4">
            <span className="text-slate-400 font-medium">Injected Context:</span>
            <span className="font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20">
              {activeKbIds.length} Active Document(s)
            </span>
          </div>

          {/* KB Document Stack */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 font-sans">
            {isLoadingKB ? (
              <div className="py-10 text-center text-slate-500 text-xs flex flex-col items-center gap-3">
                <Loader2 className="animate-spin text-emerald-400" size={24} />
                Scanning Local Filesystem...
              </div>
            ) : kbError ? (
              <div className="py-10 text-center text-red-400 text-xs flex flex-col items-center gap-2 px-4 bg-red-950/20 rounded-xl border border-red-900/30">
                <AlertCircle size={20} />
                {kbError}
                <button 
                  onClick={fetchKB}
                  className="mt-2 text-[10px] text-white underline cursor-pointer"
                >
                  Retry
                </button>
              </div>
            ) : kbDocs.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl flex flex-col items-center p-6 bg-slate-950/20">
                <FileText size={32} className="text-slate-700 mb-2" />
                No knowledge documents found
                <p className="text-[10px] text-slate-600 mt-1">
                  Upload text files, markdown articles or crawl web URLs to get started!
                </p>
                <button 
                  onClick={() => setShowAddKbModal(true)}
                  className="mt-4 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-xs transition cursor-pointer"
                >
                  Add Your First Document
                </button>
              </div>
            ) : (
              kbDocs.map((doc) => (
                <div 
                  key={doc.id}
                  onClick={() => toggleKbActive(doc.id)}
                  className={`p-3 rounded-xl border transition cursor-pointer flex items-start gap-3 select-none ${
                    doc.isActive 
                      ? 'bg-slate-800/50 border-emerald-500/40 hover:border-emerald-500/60' 
                      : 'bg-slate-900/30 border-slate-800 hover:bg-slate-900/50 hover:border-slate-700'
                  }`}
                >
                  {/* Active Indicator Slot */}
                  <div className="mt-0.5">
                    {doc.isActive ? (
                      <div className="w-4 h-4 rounded bg-emerald-500 flex items-center justify-center text-slate-950">
                        <Check size={12} strokeWidth={3} />
                      </div>
                    ) : (
                      <div className="w-4 h-4 rounded border border-slate-700 hover:border-slate-500" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      {doc.source === 'file' && <FileText size={12} className="text-blue-400" />}
                      {doc.source === 'url' && <Globe size={12} className="text-indigo-400" />}
                      {doc.source === 'manual' && <Sparkles size={12} className="text-amber-400" />}
                      
                      <h4 className="text-xs font-semibold text-white truncate">
                        {doc.title}
                      </h4>
                    </div>

                    <p className="text-[10px] text-slate-400 line-clamp-2 max-w-full font-serif break-words">
                      {doc.content}
                    </p>

                    <span className="text-[9px] text-slate-500 mt-2 block">
                      {new Date(doc.createdAt).toLocaleDateString()} &bull; Source: {doc.source}
                    </span>
                  </div>

                  <button 
                    onClick={(e) => deleteKbDoc(doc.id, e)}
                    className={`p-1.5 text-xs font-semibold rounded-lg transition cursor-pointer flex items-center gap-1 shrink-0 ${
                      deleteConfirmId === doc.id 
                        ? 'bg-red-600/90 text-white px-2 py-1 hover:bg-red-500 hover:text-white opacity-100 animate-pulse' 
                        : 'hover:bg-red-500/10 text-slate-500 hover:text-red-400 opacity-60 hover:opacity-100'
                    }`}
                    title={deleteConfirmId === doc.id ? "Click again to delete permanently" : "Delete document"}
                  >
                    {deleteConfirmId === doc.id ? (
                      <span className="text-[10px] uppercase tracking-wider font-bold">Confirm Delete?</span>
                    ) : (
                      <Trash2 size={13} />
                    )}
                  </button>
                </div>
              ))
            )}
          </div>
        </section>


        {/* ==========================================
            RIGHT COLUMN : CHAT INTERFACE & TAB PANELS
            ========================================== */}
        <section className="md:col-span-8 flex flex-col bg-slate-900/40 border border-slate-800/60 rounded-2xl overflow-hidden h-[82vh]">
          
          {/* ==========================================
              TAB SUB-PANEL 1 : CONCEPTS TEXT CHAT
              ========================================== */}
          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col min-h-0">
              
              {/* Header Details */}
              <div className="bg-slate-900/60 p-4 border-b border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot size={18} className="text-emerald-400" />
                  <span className="text-xs font-semibold text-slate-200">
                    Text-Based Assistant Chat
                  </span>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={renewChatAndClearKB}
                    className="flex items-center gap-1.5 px-3 py-1 bg-red-500/10 hover:bg-red-500/25 text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/45 rounded-lg text-[10px] font-semibold cursor-pointer transition uppercase tracking-wider"
                    title="Renew chat: clears message history and deletes all uploaded knowledge documents"
                  >
                    <RefreshCw size={11} className="mr-0.5" />
                    New Chat
                  </button>

                  {activeKbIds.length > 0 ? (
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/5 px-2.5 py-1 rounded border border-emerald-500/10 flex items-center gap-1.5 shrink-0">
                      <CheckSquare size={12} /> Custom context active
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 flex items-center gap-1.5 shrink-0">
                      <Info size={12} /> Standard model answers active
                    </span>
                  )}
                </div>
              </div>

              {/* Chat Thread */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMessages.map((msg, index) => (
                  <div 
                    key={index}
                    className={`flex gap-3 max-w-[85%] ${
                      msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''
                    }`}
                  >
                    {/* Role Icon */}
                    <div className={`p-2 rounded-xl self-start ${
                      msg.role === 'user' 
                        ? 'bg-slate-800 text-slate-300' 
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                    </div>

                    {/* Speech Box */}
                    <div>
                      <div className={`p-3.5 rounded-2xl text-xs leading-relaxed break-words whitespace-pre-wrap ${
                        msg.role === 'user' 
                          ? 'bg-slate-800 text-slate-100 rounded-tr-none' 
                          : 'bg-slate-900/60 border border-slate-800/80 text-slate-300 rounded-tl-none font-sans'
                      }`}>
                        
                        {/* Attachments preview inside the chat node balloon */}
                        {msg.image && (
                          <div className="max-w-xs mb-3.5 rounded-lg overflow-hidden border border-slate-700/60 bg-black">
                            <img 
                              src={msg.image} 
                              alt="Attached user asset" 
                              className="max-h-56 w-auto object-cover mx-auto"
                            />
                          </div>
                        )}

                        {msg.content}
                      </div>

                      <span className={`text-[9px] text-slate-500 mt-1 block px-1 ${
                        msg.role === 'user' ? 'text-right' : 'text-left'
                      }`}>
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ))}

                {isGeneratingChat && (
                  <div className="flex gap-3 max-w-[80%]">
                    <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                      <Bot size={16} className="animate-spin" />
                    </div>
                    <div className="p-3 bg-slate-900/30 border border-slate-850 text-slate-400 rounded-2xl rounded-tl-none text-xs flex items-center gap-2">
                      <RefreshCw size={12} className="animate-spin" /> Thinking... Processing Knowledge Base
                    </div>
                  </div>
                )}

                {chatError && (
                  <div className="p-4 bg-red-950/20 border border-red-900/40 rounded-xl text-red-400 text-xs flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <AlertCircle size={16} className="shrink-0" />
                      <span>{chatError}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setChatError(null)}
                      className="text-red-400/80 hover:text-red-300 p-1 hover:bg-red-500/10 rounded transition cursor-pointer"
                      title="Dismiss error"
                    >
                      <X size={14} />
                    </button>
                  </div>
                )}

                <div ref={chatEndRef} />
              </div>

              {/* Chat Send Console Form */}
              <div className="p-4 border-t border-slate-800/80 bg-slate-900/20">
                <form onSubmit={executeSendChat} className="space-y-3">
                  
                  {/* Image Attachment Preview Ribbon */}
                  {chatImageBase64 && (
                    <div className="flex items-center gap-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 w-fit relative">
                      <div className="relative w-12 h-12 rounded overflow-hidden bg-slate-900 border border-slate-800 shrink-0">
                        <img src={chatImageBase64} alt="Pre-upload preview" className="w-full h-full object-cover" />
                        <button 
                          type="button"
                          onClick={() => setChatImageBase64(null)}
                          title="Remove attached image"
                          className="absolute top-0.5 right-0.5 bg-red-600/90 hover:bg-red-500 text-white w-4 h-4 rounded-full flex items-center justify-center transition cursor-pointer"
                        >
                          <X size={10} strokeWidth={3} />
                        </button>
                      </div>
                      <div className="text-[10px]">
                        <p className="text-white font-semibold">Image Attached</p>
                        <p className="text-slate-500 mb-0.5">Ready to send to Gemini</p>
                        <button
                          type="button"
                          onClick={() => setChatImageBase64(null)}
                          className="text-[9px] text-red-400 hover:text-red-300 transition cursor-pointer font-medium underline block"
                        >
                          Remove image
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Input form element cluster */}
                  <div className="relative flex items-center gap-2 bg-slate-950 border border-slate-800/80 rounded-xl p-2 focus-within:border-emerald-500/40 transitions duration-300">
                    
                    {/* Custom Image Upload Clip Button */}
                    <label 
                      title="Attach picture (.jpeg, .png, .jpg)"
                      className="p-2 bg-slate-900 text-slate-400 hover:text-white rounded-lg cursor-pointer hover:bg-slate-800/80 transition flex items-center justify-center relative group"
                    >
                      <ImageIcon size={18} />
                      <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-900 border border-slate-800 text-[10px] text-slate-200 rounded opacity-0 pointer-events-none group-hover:opacity-100 transition whitespace-nowrap z-25">
                        Accepts .jpg, .jpeg, .png
                      </span>
                      <input 
                        type="file" 
                        accept=".jpeg,.jpg,.png,image/jpeg,image/png" 
                        onChange={handleSelectImageForChat}
                        className="hidden" 
                      />
                    </label>

                    {/* Text Field */}
                    <input 
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder={activeKbIds.length > 0 ? "Ask anything about active documents..." : "Type custom chat query with image..."}
                      className="flex-1 bg-transparent border-0 outline-none placeholder-slate-500 text-xs text-white focus:ring-0 px-2 h-10"
                    />

                    {/* Send Button */}
                    <button
                      type="submit"
                      disabled={!chatInput.trim() && !chatImageBase64}
                      className="p-2.5 bg-emerald-600 font-semibold hover:bg-emerald-500 text-white rounded-xl transition cursor-pointer disabled:opacity-40 disabled:hover:bg-emerald-600 select-none flex items-center justify-center"
                    >
                      <Send size={15} />
                    </button>
                  </div>
                </form>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB SUB-PANEL 2 : REALTIME VOICE PORTAL
              ========================================== */}
          {activeTab === 'voice' && (
            <div className="flex-1 flex flex-col min-h-0 bg-slate-950/40">
              
              {/* Header Status */}
              <div className="bg-slate-900/60 p-4 border-b border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Volume2 size={18} className="text-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold text-slate-200">
                    Gemini Live Real-time Voice Portal
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[10px]">
                  {voiceConnectionState === 'disconnected' && (
                    <span className="bg-slate-800 text-slate-400 px-2.5 py-1 rounded border border-slate-700/40">
                      &bull; Standby Offline
                    </span>
                  )}
                  {voiceConnectionState === 'connecting' && (
                    <span className="bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded border border-amber-500/20 flex items-center gap-1.5">
                      <RefreshCw size={10} className="animate-spin" /> Provisioning Audio Links...
                    </span>
                  )}
                  {voiceConnectionState === 'connected' && (
                    <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded border border-emerald-500/20 animate-pulse flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" /> Streaming Voice Link Active
                    </span>
                  )}
                </div>
              </div>

              {/* Central Immersive Glowing Core and Waveform Visualization */}
              <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-6 max-h-[50vh] border-b border-slate-800/40 relative overflow-hidden bg-radial from-emerald-950/20 to-transparent">
                
                {/* Visual Circle Glow Portal */}
                <div className="relative flex items-center justify-center">
                  
                  {/* Backdrop Pulsar Layers */}
                  <div className={`absolute w-44 h-44 rounded-full bg-emerald-500/5 border border-emerald-500/5 transition-all duration-1000 ${
                    isVoiceSessionActive ? 'scale-150 animate-ping' : 'scale-100'
                  }`} />
                  <div className={`absolute w-36 h-36 rounded-full bg-emerald-600/10 border border-emerald-600/10 transition-all duration-1000 ${
                    isVoiceSessionActive ? 'scale-125' : 'scale-100'
                  }`} />
                  
                  {/* Central Button Core Globe */}
                  <button
                    onClick={toggleVoiceSession}
                    disabled={voiceConnectionState === 'connecting'}
                    className={`w-28 h-28 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-500 shadow-2xl cursor-pointer disabled:opacity-40 select-none z-15 ${
                      isVoiceSessionActive 
                        ? 'bg-emerald-500/20 border-emerald-400 shadow-emerald-500/30 hover:bg-emerald-500/30' 
                        : 'bg-slate-900 border-slate-800 hover:bg-slate-850 hover:border-slate-700'
                    }`}
                  >
                    {isVoiceSessionActive ? (
                      <Volume2 size={38} className="text-emerald-300 animate-bounce" />
                    ) : (
                      <VolumeX size={38} className="text-slate-500" />
                    )}
                  </button>
                </div>

                {/* Status labels and alerts */}
                <div className="text-center space-y-1 z-10">
                  <h3 className="text-sm font-semibold text-white">
                    {isVoiceSessionActive ? 'Voice Assistant is Listening...' : 'Stream Session Offline'}
                  </h3>
                  <p className="text-xs text-slate-400 max-w-sm">
                    {isVoiceSessionActive 
                      ? "Keep speaking. I'm dynamically compiling custom knowledge documents." 
                      : 'Toggle the green audio core to establish the low-latency Gemini Voice API tunnel.'}
                  </p>
                </div>

                {voiceError && (
                  <div className="max-w-md p-3 bg-red-950/30 border border-red-900/30 rounded-xl text-red-400 text-xs flex items-center gap-2 z-10">
                    <AlertCircle size={14} className="shrink-0" />
                    {voiceError}
                  </div>
                )}
              </div>

              {/* Dynamic Transcript Sub-Display */}
              <div className="flex-[0.8] flex flex-col bg-slate-950/60 min-h-[160px] max-h-[30vh]">
                <div className="px-4 py-2 border-y border-slate-800/80 bg-slate-950 text-[10px] tracking-wide text-slate-500 font-semibold uppercase flex items-center justify-between">
                  <span>Voice Session Transcription Logs</span>
                  {activeKbIds.length > 0 && (
                    <span className="text-emerald-500 normal-case bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10">
                      RAG Context Activated For Voice
                    </span>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs flex flex-col font-sans">
                  {voiceTranscripts.length === 0 ? (
                    <div className="my-auto text-center text-slate-600 text-xs py-4">
                      Transcripts will generate dynamically once conversation is streaming.
                    </div>
                  ) : (
                    voiceTranscripts.map((t) => (
                      <div 
                        key={t.id}
                        className={`flex items-start gap-2.5 max-w-[90%] ${
                          t.sender === 'user' ? 'ml-auto flex-row-reverse text-right' : ''
                        }`}
                      >
                        <div className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase shrink-0 ${
                          t.sender === 'user' 
                            ? 'bg-slate-850 text-slate-400' 
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25'
                        }`}>
                          {t.sender === 'user' ? 'You' : 'AI'}
                        </div>
                        <div className={`p-2.5 rounded-xl border max-w-full break-words whitespace-pre-wrap ${
                          t.sender === 'user' 
                            ? 'bg-slate-900 border-slate-800 text-slate-300' 
                            : 'bg-emerald-500/5 border-emerald-500/10 text-slate-200'
                        }`}>
                          {t.text}
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={voiceTranscriptsEndRef} />
                </div>
              </div>

            </div>
          )}

        </section>

      </main>


      {/* ==========================================
          MODAL OVERLAY: ADD DOCUMENT CONSOLE
          ========================================== */}
      {showAddKbModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 animate-fade-in backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Database size={18} className="text-emerald-400" />
                Add Knowledge Source
              </h2>
              <button 
                onClick={() => setShowAddKbModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Source Type Selector */}
            <div className="p-5 pb-0">
              <div className="grid grid-cols-3 bg-slate-950 p-1 rounded-xl border border-slate-800/60">
                <button
                  type="button"
                  onClick={() => { setNewKbType('manual'); setAddDocError(null); }}
                  className={`py-2 rounded-lg text-xs font-semibold cursor-pointer transition ${
                    newKbType === 'manual' 
                      ? 'bg-slate-800 text-white' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  📝 Manual Text
                </button>
                <button
                  type="button"
                  onClick={() => { setNewKbType('url'); setAddDocError(null); }}
                  className={`py-2 rounded-lg text-xs font-semibold cursor-pointer transition ${
                    newKbType === 'url' 
                      ? 'bg-slate-800 text-white' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  🌐 Web URL
                </button>
                <button
                  type="button"
                  onClick={() => { setNewKbType('file'); setAddDocError(null); }}
                  className={`py-2 rounded-lg text-xs font-semibold cursor-pointer transition ${
                    newKbType === 'file' 
                      ? 'bg-slate-800 text-white' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  📁 File Upload
                </button>
              </div>
            </div>

            {/* Modal Forms Area */}
            <div className="p-5 flex-1 overflow-y-auto">
              {addDocError && (
                <div className="mb-4 p-3.5 bg-red-950/30 border border-red-900/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
                  <AlertCircle size={14} className="shrink-0" />
                  {addDocError}
                </div>
              )}

              {/* 1. MANUAL ENTRY FORM */}
              {newKbType === 'manual' && (
                <form onSubmit={handleAddManualKB} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Document Title</label>
                    <input 
                      type="text"
                      value={manualTitle}
                      onChange={(e) => setManualTitle(e.target.value)}
                      placeholder="e.g. Project Delivery Roadmap"
                      className="w-full bg-slate-950 border border-slate-800/80 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500/40"
                      required
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Document Body Content</label>
                    <textarea 
                      value={manualContent}
                      onChange={(e) => setManualContent(e.target.value)}
                      placeholder="Paste guidelines, raw specs, manuals or structured markdown tables..."
                      className="w-full h-44 bg-slate-950 border border-slate-800/80 p-3.5 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500/40 resize-none font-sans leading-relaxed"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isAddingDoc || !manualTitle.trim() || !manualContent.trim()}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition cursor-pointer disabled:opacity-40 select-none flex items-center justify-center gap-2"
                  >
                    {isAddingDoc && <Loader2 size={14} className="animate-spin" />}
                    {isAddingDoc ? 'Storing Document...' : 'Submit to Knowledge Base'}
                  </button>
                </form>
              )}

              {/* 2. CRAWLER / LINK SCRAPER FORM */}
              {newKbType === 'url' && (
                <form onSubmit={handleCrawlerKB} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Crawl Website URL</label>
                    <input 
                      type="url"
                      value={crawlUrl}
                      onChange={(e) => setCrawlUrl(e.target.value)}
                      placeholder="e.g. https://example.com/api-docs"
                      className="w-full bg-slate-950 border border-slate-800/80 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500/40"
                      required
                    />
                  </div>
                  
                  <p className="text-[11px] text-slate-500 leading-relaxed bg-slate-950 p-3.5 rounded-xl border border-slate-800/60 flex items-start gap-2">
                    <Info size={14} className="text-indigo-400 mt-0.5 shrink-0" />
                    Our system will dynamically send a fetch query to download, strip HTML wrappers, clean telemetry metrics and bundle the main documentation of this webpage as system instruction facts!
                  </p>

                  <button
                    type="submit"
                    disabled={isAddingDoc || !crawlUrl.trim()}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition cursor-pointer disabled:opacity-40 select-none flex items-center justify-center gap-2"
                  >
                    {isAddingDoc && <Loader2 size={14} className="animate-spin" />}
                    {isAddingDoc ? 'Crawling Website & Stripping HTML...' : 'Crawl Page Content'}
                  </button>
                </form>
              )}

              {/* 3. STATIC PLAIN TEXT FILE UPLOADS */}
              {newKbType === 'file' && (
                <div className="space-y-4">
                  <div className="border border-dashed border-slate-800 hover:border-emerald-500/50 bg-slate-950 rounded-2xl p-8 text-center transition cursor-pointer min-h-[160px] relative flex flex-col items-center justify-center group">
                    <input 
                      type="file" 
                      accept=".txt,.md,.json,.jpg,.jpeg,.png,.pdf,.doc,.docx,image/jpeg,image/png,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                      onChange={handleFileUploadKB}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                    />
                    
                    <FileUp size={36} className="text-slate-650 group-hover:text-emerald-400 transition mb-3" />
                    
                    <p className="text-xs font-semibold text-white">
                      Drag & Drop documents, images, PDFs or Word files
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1 leading-relaxed max-w-xs mx-auto">
                      Supports Text (.txt, .md, .json), Images (.jpg, .jpeg, .png), PDFs (.pdf), and Microsoft Word (.doc, .docx) formats
                    </p>
                  </div>

                  <p className="text-[10px] text-slate-500 text-center leading-normal">
                    Files are parsed securely on the server and converted to plain searchable RAG knowledge elements.
                  </p>
                  
                  {isAddingDoc && (
                    <div className="py-2 text-center text-xs text-emerald-400 flex items-center justify-center gap-1.5 font-semibold">
                      <Loader2 size={12} className="animate-spin" /> Processing file structure...
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
