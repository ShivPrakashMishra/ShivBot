import express from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { WebSocketServer } from 'ws';
import { GoogleGenAI, Modality } from '@google/genai';
import multer from 'multer';
import dotenv from 'dotenv';
const require = createRequire(import.meta.url);
let pdfParser: any = null;
try {
  const pdfLib = require('pdf-parse');
  pdfParser = (pdfLib && pdfLib.default) ? pdfLib.default : pdfLib;
} catch (e) {
  console.error('Failed to load local pdf-parse library:', e);
}

let mammoth: any = null;
try {
  mammoth = require('mammoth');
} catch (e) {
  console.error('Failed to load local mammoth library:', e);
}

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure the local knowledge base directory exists
const KB_PATH = path.join(__dirname, 'knowledge-base.json');

interface KBDocument {
  id: string;
  title: string;
  content: string;
  source: string; // 'manual' | 'file' | 'url'
  url?: string;
  isActive: boolean;
  createdAt: string;
}

// Local File Helper for Knowledge Base DB
function getKB(): KBDocument[] {
  if (!fs.existsSync(KB_PATH)) {
    fs.writeFileSync(KB_PATH, JSON.stringify([], null, 2));
    return [];
  }
  try {
    const raw = fs.readFileSync(KB_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading KB files', e);
    return [];
  }
}

function saveKB(data: KBDocument[]) {
  fs.writeFileSync(KB_PATH, JSON.stringify(data, null, 2));
}

// Crawler for custom website URLs
async function fetchUrlContent(url: string): Promise<{ title: string; content: string }> {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch URL: ${response.status} ${response.statusText}`);
    }
    const html = await response.text();
    
    // Simple HTML title scraper
    let title = 'Web Page Content';
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    if (titleMatch && titleMatch[1]) {
      title = titleMatch[1].trim();
    }
    
    // Simple HTML content stripping
    let cleanText = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<\/?[^>]+(>|$)/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (cleanText.length > 25000) {
      cleanText = cleanText.substring(0, 25000) + '... [Truncated due to token size optimization]';
    }

    return { title, content: cleanText };
  } catch (error: any) {
    console.error('Web crawling failed:', error);
    throw new Error(`Web crawler error: ${error.message}`);
  }
}

// Lazy initializer for Gemini Client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is missing. Configure it in Settings > Secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Model Failover Helper to prevent 429 Quota Exceeded and 503 Space demand errors on Free Tier
async function generateContentWithFallback(params: {
  preferredModel?: string;
  contents: any;
  config?: any;
}): Promise<any> {
  const aiClient = getGeminiClient();
  const primaryModel = params.preferredModel || 'gemini-3.5-flash';
  
  // We construct a dynamic failover list to maximize daily free quota (each model has 20 requests/day per key)
  const modelsChain = [primaryModel, 'gemini-3.1-flash-lite', 'gemini-flash-latest'].filter(
    (val, idx, self) => self.indexOf(val) === idx
  );

  let lastError: any = null;

  for (let i = 0; i < modelsChain.length; i++) {
    const currentModel = modelsChain[i];
    const maxAttempts = 3;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        if (i > 0) {
          console.log(`[Backup Channel] Routing query to active node: ${currentModel} (Attempt ${attempt}/${maxAttempts})`);
        } else {
          console.log(`[Active Channel] Routing query to model: ${currentModel} (Attempt ${attempt}/${maxAttempts})`);
        }
        
        const response = await aiClient.models.generateContent({
          model: currentModel,
          contents: params.contents,
          config: params.config,
        });
        return response;
      } catch (err: any) {
        lastError = err;
        const errText = String(err?.message || err || '');
        
        // Check for transient server demand/unavailable status or quota/limit errors
        const isTemporaryOrQuota = 
          errText.includes('429') || 
          errText.includes('503') ||
          errText.includes('500') ||
          errText.toLowerCase().includes('quota') || 
          errText.toLowerCase().includes('resource_exhausted') ||
          errText.toLowerCase().includes('rate limit') ||
          errText.toLowerCase().includes('limit') ||
          errText.toLowerCase().includes('overloaded') ||
          errText.toLowerCase().includes('exhausted') ||
          errText.toLowerCase().includes('unavailable') ||
          errText.toLowerCase().includes('high demand') ||
          errText.toLowerCase().includes('spikes') ||
          errText.toLowerCase().includes('temporary') ||
          errText.toLowerCase().includes('busy') ||
          errText.toLowerCase().includes('service') ||
          errText.toLowerCase().includes('capacity');

        if (isTemporaryOrQuota) {
          // If this isn't our last attempt for this model, backing off slightly with jitter can bypass momentary 503 spikes
          if (attempt < maxAttempts) {
            const delayMs = attempt * 800 + Math.floor(Math.random() * 400);
            console.warn(`[Node Busy] ${currentModel} reported load threshold. Backing off ${delayMs}ms before retry...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            continue;
          } else {
            console.warn(`[Node Exhausted] ${currentModel} exceeded attempt limit on attempt ${attempt}.`);
          }
        }
        
        // If it's a hard error (not temporary or quota), or we've run out of attempts for this model,
        // break out of the attempt loop to move to the next model in the model chain.
        break;
      }
    }
    
    // If the error isn't temporary/quota related, we might not want to fallback.
    const lastErrText = String(lastError?.message || lastError || '');
    const isRetriableError = 
      lastErrText.includes('429') || 
      lastErrText.includes('503') ||
      lastErrText.includes('500') ||
      lastErrText.toLowerCase().includes('quota') ||
      lastErrText.toLowerCase().includes('limit') ||
      lastErrText.toLowerCase().includes('unavailable') ||
      lastErrText.toLowerCase().includes('heavy demand') ||
      lastErrText.toLowerCase().includes('busy');
      
    if (!isRetriableError) {
      // If it's a genuine syntax/runtime prompt error, fail early without wasting fallback models
      break;
    }
  }

  // If we got here, all attempted models failed
  const finalErrorString = String(lastError?.message || lastError || 'Unknown connection limit');
  console.log(`[Model Chain Exhausted] Backup channels concluded: ${finalErrorString.substring(0, 180)}`);
  
  throw new Error(
    `The AI service is temporarily experiencing high request density on its Free Tier. Please wait a brief moment and submit your message again. (${finalErrorString})`
  );
}

// Streaming Model Failover Helper for high-performance direct chat delivery
async function* generateContentStreamWithFallback(params: {
  preferredModel?: string;
  contents: any;
  config?: any;
}): AsyncGenerator<string, void, unknown> {
  const aiClient = getGeminiClient();
  const primaryModel = params.preferredModel || 'gemini-3.5-flash';
  
  // Construct dynamic failover chain matching standard content helpers
  const modelsChain = [primaryModel, 'gemini-3.1-flash-lite', 'gemini-flash-latest'].filter(
    (val, idx, self) => self.indexOf(val) === idx
  );

  let lastError: any = null;

  for (let i = 0; i < modelsChain.length; i++) {
    const currentModel = modelsChain[i];
    const maxAttempts = 3;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        if (i > 0) {
          console.log(`[Backup Stream Channel] Routing query to active node: ${currentModel} (Attempt ${attempt}/${maxAttempts})`);
        } else {
          console.log(`[Active Stream Channel] Routing query to model: ${currentModel} (Attempt ${attempt}/${maxAttempts})`);
        }
        
        const responseStream = await aiClient.models.generateContentStream({
          model: currentModel,
          contents: params.contents,
          config: params.config,
        });

        for await (const chunk of responseStream) {
          if (chunk.text) {
            yield chunk.text;
          }
        }
        return;
      } catch (err: any) {
        lastError = err;
        const errText = String(err?.message || err || '');
        
        const isTemporaryOrQuota = 
          errText.includes('429') || 
          errText.includes('503') ||
          errText.includes('500') ||
          errText.toLowerCase().includes('quota') || 
          errText.toLowerCase().includes('resource_exhausted') ||
          errText.toLowerCase().includes('rate limit') ||
          errText.toLowerCase().includes('limit') ||
          errText.toLowerCase().includes('overloaded') ||
          errText.toLowerCase().includes('exhausted') ||
          errText.toLowerCase().includes('unavailable') ||
          errText.toLowerCase().includes('high demand') ||
          errText.toLowerCase().includes('spikes') ||
          errText.toLowerCase().includes('temporary') ||
          errText.toLowerCase().includes('busy') ||
          errText.toLowerCase().includes('service') ||
          errText.toLowerCase().includes('capacity');

        if (isTemporaryOrQuota) {
          if (attempt < maxAttempts) {
            const delayMs = attempt * 800 + Math.floor(Math.random() * 400);
            console.warn(`[Node Busy Stream] ${currentModel} reported load threshold. Backing off ${delayMs}ms before retry...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            continue;
          } else {
            console.warn(`[Node Exhausted Stream] ${currentModel} exceeded attempt limit on attempt ${attempt}.`);
          }
        }
        
        break;
      }
    }
    
    const lastErrText = String(lastError?.message || lastError || '');
    const isRetriableError = 
      lastErrText.includes('429') || 
      lastErrText.includes('503') ||
      lastErrText.includes('500') ||
      lastErrText.toLowerCase().includes('quota') ||
      lastErrText.toLowerCase().includes('limit') ||
      lastErrText.toLowerCase().includes('unavailable') ||
      lastErrText.toLowerCase().includes('heavy demand') ||
      lastErrText.toLowerCase().includes('busy');
      
    if (!isRetriableError) {
      break;
    }
  }

  const finalErrorString = String(lastError?.message || lastError || 'Unknown connection limit');
  console.log(`[Model Chain Exhausted Stream] Backup channels concluded: ${finalErrorString.substring(0, 180)}`);
  
  throw new Error(
    `The AI service is temporarily experiencing high request density on its Free Tier. Please wait a brief moment and submit your message again. (${finalErrorString})`
  );
}

// Setup Express
const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Setup Multer for document imports
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}
const upload = multer({ dest: UPLOAD_DIR });

// ==========================================
// KNOWLEDGE BASE REST API ENDPOINTS
// ==========================================

// GET all documents
app.get('/api/kb', (req, res) => {
  try {
    res.json(getKB());
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST structured document (Manual / URL crawler)
app.post('/api/kb', async (req, res) => {
  try {
    const { title, content, source, url } = req.body;
    const kb = getKB();
    let newDoc: KBDocument;

    if (source === 'url') {
      if (!url) {
        return res.status(400).json({ error: 'url parameter is required' });
      }
      const scraped = await fetchUrlContent(url);
      newDoc = {
        id: 'kb_' + Date.now(),
        title: scraped.title || url,
        content: scraped.content,
        source: 'url',
        url,
        isActive: true,
        createdAt: new Date().toISOString()
      };
    } else {
      if (!title || !content) {
        return res.status(400).json({ error: 'title and content are required' });
      }
      newDoc = {
        id: 'kb_' + Date.now(),
        title,
        content,
        source: source || 'manual',
        isActive: true,
        createdAt: new Date().toISOString()
      };
    }

    kb.push(newDoc);
    saveKB(kb);
    res.status(201).json(newDoc);
  } catch (error: any) {
    console.error('KB insertion error:', error);
    res.status(500).json({ error: error.message || 'Error occurred handling knowledge document' });
  }
});

// UPLOAD static markdown, text file, or image file
app.post('/api/kb/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file supplied' });
    }

    const { originalname, path: filePath } = req.file;
    const ext = path.extname(originalname).toLowerCase();
    const isImage = ext === '.jpg' || ext === '.jpeg' || ext === '.png';
    const isPdf = ext === '.pdf';
    const isDoc = ext === '.doc' || ext === '.docx';

    if (ext !== '.txt' && ext !== '.md' && ext !== '.json' && !isImage && !isPdf && !isDoc) {
      fs.unlinkSync(filePath);
      return res.status(400).json({ error: 'Uploads are limited to text (.txt, .md, .json), images (.jpg, .jpeg, .png), PDFs (.pdf), or Word (.doc, .docx) formats.' });
    }

    let content = '';

    if (isImage) {
      // Process image file via Gemini vision to extract its knowledge
      const fileBuffer = fs.readFileSync(filePath);
      const base64Data = fileBuffer.toString('base64');
      const mimeType = ext === '.png' ? 'image/png' : 'image/jpeg';

      console.log(`Processing knowledge image ${originalname} via Gemini for RAG ingestion...`);
      const response = await generateContentWithFallback({
        preferredModel: 'gemini-3.5-flash',
        contents: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          },
          {
            text: "Extract and analyze all knowledge, readable text, schedules, formulas, diagrams, tables, and visual insights from this image. Transcribe it comprehensively in a highly structured textual description so that a chatbot can query and answer questions about it as part of a Knowledge Base context."
          }
        ]
      });

      content = response.text || '(No text could be extracted or processed from this image)';
      console.log(`Successfully ingested image via vision. Rendered length: ${content.length}`);
    } else if (isPdf) {
      console.log(`Parsing PDF file ${originalname} with dual-route parser...`);
      const fileBuffer = fs.readFileSync(filePath);
      let parsedSuccessfully = false;

      // 1. Try local PDF Parsing
      if (pdfParser && typeof pdfParser === 'function') {
        try {
          console.log(`Attempting local pdf-parse for ${originalname}...`);
          const parsedPdf = await pdfParser(fileBuffer);
          content = parsedPdf.text || '';
          if (content.trim()) {
            parsedSuccessfully = true;
            console.log(`Successfully parsed PDF locally with pdf-parse. Length: ${content.length}`);
          } else {
            console.log('Local pdf-parse returned empty content, using Gemini API fallback...');
          }
        } catch (pdfErr: any) {
          console.warn('Local pdf-parse encountered an error, falling back to Gemini API parsing:', pdfErr);
        }
      } else {
        console.log('Local pdfParser is not available, falling back to Gemini API parsing...');
      }

      // 2. Fallback to Gemini Document Parsing
      if (!parsedSuccessfully) {
        try {
          console.log(`Performing Gemini-powered API extraction for PDF: ${originalname}...`);
          const base64Data = fileBuffer.toString('base64');
          const response = await generateContentWithFallback({
            preferredModel: 'gemini-3.5-flash',
            contents: [
              {
                inlineData: {
                  data: base64Data,
                  mimeType: 'application/pdf'
                }
              },
              {
                text: "Extract and structure all text, figures, charts, tables, code snippets, notes, and information from this PDF document as comprehensive markdown text. Output the pure transcription so we can use it to populate our local search database."
              }
            ]
          });
          content = response.text || '(Empty PDF Document after Gemini parsing)';
          console.log(`Gemini content extraction completed. Extracted length: ${content.length}`);
        } catch (geminiPdfErr: any) {
          console.error('Gemini fallback PDF parser failed:', geminiPdfErr);
          throw new Error(`Failed to parse PDF document: could not parse locally or via Gemini API. Error: ${geminiPdfErr.message}`);
        }
      }
    } else if (isDoc) {
      console.log(`Parsing Word document ${originalname} via mammoth...`);
      try {
        if (!mammoth) {
          throw new Error('Mammoth parsing library is not loaded on this server');
        }
        
        let result: any = null;
        try {
          // Attempt 1: Path based
          console.log(`Attempting path-based Mammoth parsing...`);
          result = await mammoth.extractRawText({ path: filePath });
        } catch (pathErr) {
          console.warn('Mammoth path-based extraction failed, trying buffer based...', pathErr);
          // Attempt 2: Buffer based
          const fileBuffer = fs.readFileSync(filePath);
          result = await mammoth.extractRawText({ buffer: fileBuffer });
        }

        content = result.value || '';
        
        // If mammoth got nothing, fallback
        if (!content.trim()) {
          throw new Error('Mammoth returned empty text extraction');
        }
        
        console.log(`Successfully parsed Word file using mammoth. Length: ${content.length}`);
      } catch (docxError: any) {
        console.warn(`Mammoth failed on ${originalname}: ${docxError.message}. Initiating smart ASCII fallback...`);
        // Fallback: Smart Binary/ASCII string extraction
        try {
          const buffer = fs.readFileSync(filePath);
          const strings: string[] = [];
          let currentString = '';
          for (let i = 0; i < buffer.length; i++) {
            const char = buffer[i];
            // Match printable ASCII characters
            if (char >= 32 && char <= 126) {
              currentString += String.fromCharCode(char);
            } else if (char === 10 || char === 13 || char === 9) {
              currentString += String.fromCharCode(char);
            } else {
              const trimmed = currentString.trim();
              if (trimmed.length > 3) {
                // Ignore common zip/XML schema boilerplate headers to keep context cleaner
                if (
                  !trimmed.startsWith('[Content_Types]') && 
                  !trimmed.includes('xmlschema') && 
                  !trimmed.startsWith('PK') &&
                  !trimmed.includes('schemas.openxmlformats')
                ) {
                  strings.push(trimmed);
                }
              }
              currentString = '';
            }
          }
          if (currentString.trim().length > 3) {
            strings.push(currentString.trim());
          }
          
          content = strings.join('\n');
          console.log(`Smart ASCII fallback parsed Word file. Length: ${content.length}`);
        } catch (fallbackErr: any) {
          console.error('Even the Word ASCII fallback failed:', fallbackErr);
          content = `[Extraction Error for ${originalname}: ${docxError.message}]`;
        }
      }
      
      if (!content || !content.trim()) {
        content = '(Empty Word Document)';
      }
    } else {
      content = fs.readFileSync(filePath, 'utf-8');
    }

    fs.unlinkSync(filePath);

    const kb = getKB();
    const newDoc: KBDocument = {
      id: 'kb_' + Date.now(),
      title: originalname,
      content,
      source: 'file',
      isActive: true,
      createdAt: new Date().toISOString()
    };

    kb.push(newDoc);
    saveKB(kb);
    res.status(201).json(newDoc);
  } catch (error: any) {
    console.error('KB file process issue:', error);
    res.status(500).json({ error: error.message || 'Could not process uploaded context file' });
  }
});

// PUT update document status or edits
app.put('/api/kb/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, isActive } = req.body;
    const kb = getKB();
    const idx = kb.findIndex(d => d.id === id);

    if (idx === -1) {
      return res.status(404).json({ error: 'Knowledge artifact not found' });
    }

    if (title !== undefined) kb[idx].title = title;
    if (content !== undefined) kb[idx].content = content;
    if (isActive !== undefined) kb[idx].isActive = isActive;

    saveKB(kb);
    res.json(kb[idx]);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE a document
app.delete('/api/kb/:id', (req, res) => {
  try {
    const { id } = req.params;
    const kb = getKB();
    const filtered = kb.filter(d => d.id !== id);
    saveKB(filtered);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST clear all documents (reset KB)
app.post('/api/kb/clear', (req, res) => {
  try {
    saveKB([]);
    res.json({ success: true, message: 'All documents cleared successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// CHAT API WITH CUSTOM KNOWLEDGE BASE & IMAGES
// ==========================================
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, activeKbIds } = req.body;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Invalid message structure' });
    }

    // Resolve custom knowledge papers
    const kb = getKB();
    const activeDocs = kb.filter(doc => activeKbIds?.includes(doc.id) && doc.isActive);
    
    let systemInstruction = "You are a professional customized assistant. You have access to the user's uploaded custom knowledge base documents below.\n";
    if (activeDocs.length > 0) {
      systemInstruction += "YOU MUST USE AND ANSWER IN ACCORDANCE WITH THESE ACTIVE DOCUMENTS. Integrate information accurately. If a question is not covered in the documents, declare that you did not find details in the files but will offer a general explanation:\n";
      activeDocs.forEach((doc, idx) => {
        systemInstruction += `\n[Context Document ${idx + 1}: ${doc.title}]\n${doc.content}\n`;
      });
    } else {
      systemInstruction += "There are currently no active system knowledge files. Please answer using your standard instruction guidelines.";
    }

    // Reconstruct full thread history
    const contents: any[] = [];
    for (let i = 0; i < messages.length - 1; i++) {
      const msg = messages[i];
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      });
    }

    // Capture last message (with image base64 elements if sent)
    const lastMsg = messages[messages.length - 1];
    const currentParts: any[] = [];

    if (lastMsg.image) {
      const match = lastMsg.image.match(/^data:(image\/[a-zA-Z0-9.-]+);base64,(.+)$/);
      if (match) {
        currentParts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          }
        });
      } else {
        currentParts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: lastMsg.image,
          }
        });
      }
    }

    currentParts.push({ text: lastMsg.content || 'Briefly explain this image.' });

    contents.push({
      role: 'user',
      parts: currentParts
    });

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');

    const stream = generateContentStreamWithFallback({
      preferredModel: 'gemini-3.5-flash',
      contents,
      config: {
        systemInstruction,
      }
    });

    for await (const chunk of stream) {
      res.write(chunk);
    }
    res.end();
  } catch (error: any) {
    console.error('Chat endpoint error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message || 'An error occurred during response orchestration' });
    } else {
      res.write(`\n\n[Stream Error: ${error.message || 'connection lost'}]`);
      res.end();
    }
  }
});


// ==========================================
// HTTP SERVER & WEBSOCKET AUDIO BRIDGE
// ==========================================
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/live' });

wss.on('connection', async (clientWs, req) => {
  console.log('Client connected to voice ws bridge');
  
  // Scrape url parameters
  const urlParams = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`).searchParams;
  const activeKbIds = urlParams.get('activeKbIds')?.split(',').filter(Boolean) || [];

  const kb = getKB();
  const activeDocs = kb.filter(doc => activeKbIds.includes(doc.id));

  // Construct precise prompt context for real-time voice
  let voiceInstruction = "You are a friendly, conversational voice assistant speaking with the user. You speak clearly and dynamically in brief, natural paragraphs. Crucially, DO NOT use markdown format (like lists, headings, asterisks, double asterisks, bullets) because your outputs are being spoken out loud and markdown ruins text-to-speech outputs. Keep responses to a few short, concise sentences.";
  
  if (activeDocs.length > 0) {
    voiceInstruction += "\n\nCRITICAL CONTEXT: Answer strictly drawing facts from the user's knowledge documents below. Do not invent details outside of this scope. If details are missing, concisely mention that your active knowledge base does not hold the exact answer:\n";
    activeDocs.forEach(doc => {
      voiceInstruction += `\n[Document Name: ${doc.title}]\n${doc.content}\n`;
    });
  }

  let session: any = null;

  try {
    const aiClient = getGeminiClient();
    session = await aiClient.live.connect({
      model: "gemini-3.1-flash-live-preview",
      callbacks: {
        onmessage: (msg: any) => {
          // 1. Process audio chunks
          const audioChunk = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (audioChunk) {
            clientWs.send(JSON.stringify({ type: 'audio', data: audioChunk }));
          }

          // 2. Identify interruptions
          if (msg.serverContent?.interrupted) {
            clientWs.send(JSON.stringify({ type: 'interrupted' }));
          }

          // 3. Process realtime textual transcription of what standard speech is speaking
          // This gives users immediate transcript reading
          const outTranscription = msg.serverContent?.modelTurn?.parts?.[0]?.text;
          if (outTranscription) {
            clientWs.send(JSON.stringify({ type: 'transcription', origin: 'model', text: outTranscription }));
          }
        },
        onclose: () => {
          console.log('Gemini Live session closed internally');
          if (clientWs.readyState === clientWs.OPEN) {
            clientWs.close();
          }
        },
        onerror: (err: any) => {
          console.error('Gemini Live dynamic error:', err);
          clientWs.send(JSON.stringify({ type: 'error', text: err.message || 'Gemini voice link severed' }));
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' } // Friendly, warm voice
          }
        },
        systemInstruction: voiceInstruction,
      }
    });

    clientWs.send(JSON.stringify({ type: 'ready' }));
    console.log('Connected dynamically to Gemini Live interface');
  } catch (error: any) {
    console.error('Bridge boot failure:', error);
    clientWs.send(JSON.stringify({ type: 'error', text: error.message || 'Unable to provision realtime voice stream links' }));
    clientWs.close();
    return;
  }

  // Bridging Microphone buffer frames to Gemini Live socket
  clientWs.on('message', (message) => {
    try {
      const parsed = JSON.parse(message.toString());
      if (parsed.type === 'audio' && parsed.data && session) {
        session.sendRealtimeInput({
          audio: {
            data: parsed.data, // 16kHz PCM Base64 chunk
            mimeType: 'audio/pcm;rate=16000'
          }
        });
      }
    } catch (err: any) {
      console.error('Bridge user message fail:', err);
    }
  });

  clientWs.on('close', () => {
    console.log('Voice socket client link severed');
    if (session) {
      try {
        session.close();
      } catch (e) {}
    }
  });
});

// Serve frontend Spa static assets
const isProd = process.env.NODE_ENV === 'production';

if (!isProd) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
  console.log('🛠️ Vite middleware compiled successfully');
} else {
  const distPath = path.join(__dirname, 'dist');
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
  console.log('📦 Serving production bundles from:', distPath);
}

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`⚡ Full-stack live service online on port ${PORT}`);
});
